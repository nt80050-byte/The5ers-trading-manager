# The5ers Trading Manager — Android Native

## Có trong dự án
- Máy tính lot size XAU/USD: balance, risk, contract size, minimum lot (không thấp hơn 0.01), entry, SL, chi phí dự phòng.
- Cảnh báo nếu minimum lot làm risk thực tế vượt ngân sách.
- Checklist trước khi vào lệnh.
- Trading Journal: ngày giờ, BUY/SELL, phiên, setup, Entry/Exit/SL/TP, lot, risk USD, P/L, R-Multiple, tâm lý, ghi chú, vi phạm kế hoạch, ảnh chart.
- Lưu lịch sử giao dịch vào bộ nhớ riêng của ứng dụng (SharedPreferences JSON); ảnh chart được sao chép vào thư mục riêng của app.
- Analytics: Net P/L, Win Rate, Profit Factor, Average R, số lệnh, Max Equity Drawdown, breakdown theo setup và phiên.
- Weekly Review: tóm tắt và câu hỏi tự đánh giá.

## Yêu cầu
- Android Studio bản ổn định có Android SDK Platform 35.
- JDK 17.
- Internet trong lần build đầu để Gradle tải plugin/thư viện. Bản APK sau khi build có thể chạy offline.

## Build APK
1. Giải nén ZIP.
2. Mở Android Studio → Open → chọn thư mục `The5ersTradingManager`.
3. Chờ Gradle Sync hoàn tất.
4. Chọn Build → Build Bundle(s) / APK(s) → Build APK(s).
5. APK debug được tạo tại `app/build/outputs/apk/debug/app-debug.apk`.
6. Chép APK sang điện thoại Android, mở file và cho phép cài ứng dụng từ nguồn này nếu Android yêu cầu.

Có thể build bằng terminal trong thư mục dự án:
`gradle assembleDebug`

## Lưu ý quan trọng
- Đây là source project Android Studio, chưa phải file APK đã biên dịch. Môi trường tạo file không có Android SDK/Gradle nên không thể xác nhận APK build thành công tại đây.
- Contract size mặc định 100 oz/lot chỉ là giá trị khởi tạo; cần kiểm tra Specification của đúng symbol/account.
- Journal dùng dữ liệu nhập thủ công; không kết nối Exness/The5ers, không tự lấy giá, equity hay lịch sử lệnh.
- Bản 1.0 chưa có đồng bộ cloud, export CSV, backup/restore UI, biểu đồ equity trực quan, hay bộ lọc tuần tự động. Cần sao lưu dữ liệu app trước khi gỡ cài đặt.
- Chỉ số Max Equity DD trong Analytics là drawdown từ chuỗi P/L đã nhập, không thay thế drawdown chính thức theo quy tắc quỹ.

## Build APK trên cloud (không cần cài Android Studio trên điện thoại)
Dự án có sẵn workflow GitHub Actions tại `.github/workflows/build-apk.yml`.
1. Tạo một repository GitHub mới và upload toàn bộ nội dung thư mục dự án.
2. Mở tab Actions của repository, chọn workflow `Build Android APK`.
3. Nhấn `Run workflow` và chờ job hoàn tất.
4. Mở kết quả workflow, tải artifact `The5ers-Trading-Manager-debug-apk` về điện thoại.
5. Giải nén artifact ZIP để lấy `app-debug.apk`, sau đó mở APK để cài đặt.
