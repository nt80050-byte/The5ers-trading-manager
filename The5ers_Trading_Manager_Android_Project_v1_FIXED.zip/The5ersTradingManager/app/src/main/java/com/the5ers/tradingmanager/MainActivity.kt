package com.the5ers.tradingmanager

import android.content.Context
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.Book
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max

private val Bg = Color(0xFF0B1220)
private val Panel = Color(0xFF141F30)
private val Green = Color(0xFF62D6A5)
private val Muted = Color(0xFF9AABC0)
private val Red = Color(0xFFFF858F)

data class Trade(
    val id: Long,
    val date: String,
    val symbol: String,
    val side: String,
    val session: String,
    val setup: String,
    val entry: Double,
    val exit: Double,
    val sl: Double,
    val tp: Double,
    val lot: Double,
    val risk: Double,
    val pnl: Double,
    val rMultiple: Double,
    val notes: String,
    val emotion: String,
    val ruleBreak: Boolean,
    val imagePath: String
)

class TradeStore(context: Context) {
    private val prefs = context.getSharedPreferences("the5ers_journal", Context.MODE_PRIVATE)
    fun load(): List<Trade> {
        val arr = try { JSONArray(prefs.getString("trades", "[]")) } catch (_: Exception) { JSONArray() }
        return (0 until arr.length()).mapNotNull { i ->
            try {
                val o = arr.getJSONObject(i)
                Trade(
                    o.optLong("id"), o.optString("date"), o.optString("symbol", "XAU/USD"),
                    o.optString("side"), o.optString("session"), o.optString("setup"),
                    o.optDouble("entry"), o.optDouble("exit"), o.optDouble("sl"), o.optDouble("tp"),
                    o.optDouble("lot"), o.optDouble("risk"), o.optDouble("pnl"), o.optDouble("r"),
                    o.optString("notes"), o.optString("emotion"), o.optBoolean("ruleBreak"),
                    o.optString("imagePath")
                )
            } catch (_: Exception) { null }
        }
    }
    fun save(trades: List<Trade>) {
        val arr = JSONArray()
        trades.forEach { t ->
            arr.put(JSONObject().apply {
                put("id", t.id); put("date", t.date); put("symbol", t.symbol); put("side", t.side)
                put("session", t.session); put("setup", t.setup); put("entry", t.entry); put("exit", t.exit)
                put("sl", t.sl); put("tp", t.tp); put("lot", t.lot); put("risk", t.risk)
                put("pnl", t.pnl); put("r", t.rMultiple); put("notes", t.notes); put("emotion", t.emotion)
                put("ruleBreak", t.ruleBreak); put("imagePath", t.imagePath)
            })
        }
        prefs.edit().putString("trades", arr.toString()).apply()
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(16, 24, 39)
        window.navigationBarColor = android.graphics.Color.rgb(8, 14, 24)
        setContent { AppRoot() }
    }
}

@Composable
fun AppRoot() {
    val context = LocalContext.current
    val store = remember { TradeStore(context) }
    var trades by remember { mutableStateOf(store.load()) }
    var tab by remember { mutableIntStateOf(0) }
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Green, secondary = Green, background = Bg, surface = Panel,
            onPrimary = Color(0xFF062319), onBackground = Color.White, onSurface = Color.White
        )
    ) {
        Scaffold(
            containerColor = Bg,
            topBar = {
                Column(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 14.dp)) {
                    Text("THE5ERS • HIGH STAKES", color = Green, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                    Text("Trading Manager", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                    Text("XAU/USD  ·  Risk discipline  ·  Trading Journal", color = Muted, style = MaterialTheme.typography.bodySmall)
                }
            },
            bottomBar = {
                NavigationBar(containerColor = Panel) {
                    NavigationBarItem(selected = tab == 0, onClick = { tab = 0 }, icon = { Icon(Icons.Default.Calculate, null) }, label = { Text("Lot Size") })
                    NavigationBarItem(selected = tab == 1, onClick = { tab = 1 }, icon = { Icon(Icons.Default.Book, null) }, label = { Text("Journal") })
                    NavigationBarItem(selected = tab == 2, onClick = { tab = 2 }, icon = { Icon(Icons.Default.Assessment, null) }, label = { Text("Analytics") })
                    NavigationBarItem(selected = tab == 3, onClick = { tab = 3 }, icon = { Icon(Icons.Default.CalendarMonth, null) }, label = { Text("Review") })
                }
            }
        ) { padding ->
            when (tab) {
                0 -> CalculatorScreen(Modifier.padding(padding))
                1 -> JournalScreen(Modifier.padding(padding), trades, onAdd = { t -> trades = listOf(t) + trades; store.save(trades) }, onDelete = { id -> trades = trades.filterNot { it.id == id }; store.save(trades) })
                2 -> AnalyticsScreen(Modifier.padding(padding), trades)
                else -> ReviewScreen(Modifier.padding(padding), trades)
            }
        }
    }
}

@Composable
fun AppCard(content: @Composable ColumnScope.() -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
        colors = CardDefaults.cardColors(containerColor = Panel),
        shape = RoundedCornerShape(18.dp)
    ) { Column(Modifier.padding(16.dp), content = content) }
}

@Composable
fun Field(label: String, value: String, onChange: (String) -> Unit, modifier: Modifier = Modifier, numeric: Boolean = false) {
    Column(modifier) {
        Text(label, color = Muted, style = MaterialTheme.typography.labelMedium)
        Spacer(Modifier.height(5.dp))
        OutlinedTextField(
            value = value, onValueChange = onChange, modifier = Modifier.fillMaxWidth(),
            singleLine = true, keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(
                keyboardType = if (numeric) androidx.compose.ui.text.input.KeyboardType.Decimal else androidx.compose.ui.text.input.KeyboardType.Text
            ),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = Green, unfocusedBorderColor = Color(0xFF34465E),
                focusedTextColor = Color.White, unfocusedTextColor = Color.White,
                focusedContainerColor = Color(0xFF0C1625), unfocusedContainerColor = Color(0xFF0C1625)
            )
        )
    }
}

@Composable
fun CalculatorScreen(modifier: Modifier = Modifier) {
    var balance by remember { mutableStateOf("2500") }
    var risk by remember { mutableStateOf("25") }
    var contract by remember { mutableStateOf("100") }
    var minLot by remember { mutableStateOf("0.01") }
    var entry by remember { mutableStateOf("4000") }
    var sl by remember { mutableStateOf("3995") }
    var cost by remember { mutableStateOf("0") }
    var calculated by remember { mutableStateOf(false) }
    val dist = abs((entry.toDoubleOrNull() ?: 0.0) - (sl.toDoubleOrNull() ?: 0.0))
    val riskD = risk.toDoubleOrNull() ?: 0.0
    val cs = contract.toDoubleOrNull() ?: 100.0
    val minD = max(0.01, minLot.toDoubleOrNull() ?: 0.01)
    val costD = cost.toDoubleOrNull() ?: 0.0
    val raw = if (dist > 0 && cs > 0 && riskD > costD) (riskD - costD) / (dist * cs) else 0.0
    val lot = if (raw > 0) max(minD, raw) else 0.0
    val actual = lot * dist * cs + costD
    val safe = raw >= minD
    Column(modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        AppCard {
            Text("01 · TÍNH KHỐI LƯỢNG LỆNH", fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Field("Balance ($)", balance, { balance = it }, Modifier.weight(1f), true)
                Field("Risk mỗi lệnh ($)", risk, { risk = it }, Modifier.weight(1f), true)
            }
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Field("Contract size (oz/lot)", contract, { contract = it }, Modifier.weight(1f), true)
                Field("Lot tối thiểu", minLot, { minLot = it }, Modifier.weight(1f), true)
            }
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Field("Entry price", entry, { entry = it }, Modifier.weight(1f), true)
                Field("Stop Loss price", sl, { sl = it }, Modifier.weight(1f), true)
            }
            Spacer(Modifier.height(10.dp))
            Field("Chi phí dự phòng ($)", cost, { cost = it }, numeric = true)
            Button(onClick = { calculated = true }, modifier = Modifier.fillMaxWidth().padding(top = 12.dp)) { Text("TÍNH LOT SIZE") }
            if (calculated) {
                Spacer(Modifier.height(14.dp))
                Surface(color = if (safe) Color(0xFF123B36) else Color(0xFF3A2028), shape = RoundedCornerShape(16.dp)) {
                    Column(Modifier.padding(16.dp)) {
                        Text("Khối lượng đề xuất", color = Muted)
                        Text(if (lot > 0) "${fmtLot(lot)} lot" else "—", color = if (safe) Green else Red, style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.ExtraBold)
                        Spacer(Modifier.height(10.dp))
                        Text("Khoảng SL: $${"%.2f".format(dist)}")
                        Text("Risk ước tính: $${"%.2f".format(actual)}")
                        Text("Risk / Balance: ${"%.2f".format(if ((balance.toDoubleOrNull() ?: 0.0) > 0) actual / balance.toDouble() * 100 else 0.0)}%")
                        Text("Giá trị $1 biến động: $${"%.2f".format(lot * cs)}")
                    }
                }
                Spacer(Modifier.height(8.dp))
                Text(
                    if (safe) "Khối lượng nằm trong ngân sách risk."
                    else "CẢNH BÁO: Lot tối thiểu làm risk thực tế ($${"%.2f".format(actual)}) vượt ngân sách ($${"%.2f".format(riskD)}). Không tự động chấp nhận mức risk này.",
                    color = if (safe) Green else Red, style = MaterialTheme.typography.bodySmall
                )
            }
            Text("Mặc định 100 oz/lot. Hãy xác nhận Contract Specification của đúng tài khoản/sàn.", color = Muted, style = MaterialTheme.typography.bodySmall)
        }
        AppCard {
            Text("02 · CHECKLIST TRƯỚC KHI VÀO LỆNH", fontWeight = FontWeight.Bold)
            val items = listOf(
                "Đã xác định Entry, SL và TP trước khi vào lệnh",
                "Đã tính lot size và kiểm tra risk thực tế",
                "Tỷ lệ Risk/Reward phù hợp kế hoạch",
                "Không vào lệnh vì FOMO hoặc muốn gỡ lỗ",
                "Đã kiểm tra lịch tin tức và điều kiện thị trường",
                "Tâm lý ổn định, sẵn sàng chấp nhận khoản lỗ"
            )
            var checked by remember { mutableStateOf(setOf<Int>()) }
            items.forEachIndexed { i, item ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = i in checked, onCheckedChange = { yes -> checked = if (yes) checked + i else checked - i })
                    Text(item, color = Color.White, style = MaterialTheme.typography.bodySmall)
                }
            }
            Text("${checked.size}/${items.size} mục hoàn thành", color = if (checked.size == items.size) Green else Muted)
        }
    }
}

fun fmtLot(x: Double): String = String.format(Locale.US, "%.3f", x).trimEnd('0').trimEnd('.')

@Composable
fun JournalScreen(modifier: Modifier, trades: List<Trade>, onAdd: (Trade) -> Unit, onDelete: (Long) -> Unit) {
    var show by remember { mutableStateOf(false) }
    Column(modifier.fillMaxSize().padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
            Column { Text("TRADING JOURNAL", fontWeight = FontWeight.Bold); Text("${trades.size} giao dịch đã lưu", color = Muted, style = MaterialTheme.typography.bodySmall) }
            Button(onClick = { show = true }) { Icon(Icons.Default.Add, null); Text(" Ghi lệnh") }
        }
        Spacer(Modifier.height(12.dp))
        if (trades.isEmpty()) {
            AppCard { Text("Chưa có giao dịch", fontWeight = FontWeight.Bold); Text("Nhấn “Ghi lệnh” để lưu giao dịch đầu tiên.", color = Muted) }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(trades, key = { it.id }) { t ->
                    AppCard {
                        Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                            Text("${t.side} · ${t.symbol}", fontWeight = FontWeight.Bold)
                            Text(if (t.pnl >= 0) "+$${"%.2f".format(t.pnl)}" else "-$${"%.2f".format(abs(t.pnl))}", color = if (t.pnl >= 0) Green else Red, fontWeight = FontWeight.Bold)
                        }
                        Text("${t.date} · ${t.session} · ${t.setup}", color = Muted, style = MaterialTheme.typography.bodySmall)
                        Text("Entry ${t.entry} → Exit ${t.exit} · ${fmtLot(t.lot)} lot")
                        Text("Risk $${"%.2f".format(t.risk)} · ${"%.2f".format(t.rMultiple)}R")
                        if (t.ruleBreak) Text("Vi phạm kế hoạch", color = Red)
                        if (t.notes.isNotBlank()) Text(t.notes, color = Muted, style = MaterialTheme.typography.bodySmall)
                        TextButton(onClick = { onDelete(t.id) }) { Text("Xóa giao dịch", color = Red) }
                    }
                }
            }
        }
    }
    if (show) TradeDialog(onDismiss = { show = false }, onSave = { onAdd(it); show = false })
}

@Composable
fun TradeDialog(onDismiss: () -> Unit, onSave: (Trade) -> Unit) {
    val context = LocalContext.current
    var side by remember { mutableStateOf("BUY") }
    var session by remember { mutableStateOf("New York") }
    var setup by remember { mutableStateOf("OB") }
    var emotion by remember { mutableStateOf("Bình tĩnh") }
    var date by remember { mutableStateOf(SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date())) }
    var entry by remember { mutableStateOf("") }; var exit by remember { mutableStateOf("") }
    var sl by remember { mutableStateOf("") }; var tp by remember { mutableStateOf("") }
    var lot by remember { mutableStateOf("0.01") }; var risk by remember { mutableStateOf("25") }
    var pnl by remember { mutableStateOf("") }; var notes by remember { mutableStateOf("") }
    var ruleBreak by remember { mutableStateOf(false) }; var imagePath by remember { mutableStateOf("") }
    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) {
            try {
                val target = File(context.filesDir, "trade_${System.currentTimeMillis()}.jpg")
                context.contentResolver.openInputStream(uri)?.use { input -> target.outputStream().use { output -> input.copyTo(output) } }
                imagePath = target.absolutePath
            } catch (_: Exception) { imagePath = "" }
        }
    }
    val riskD = risk.toDoubleOrNull() ?: 0.0
    val pnlD = pnl.toDoubleOrNull() ?: 0.0
    val r = if (riskD > 0) pnlD / riskD else 0.0
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Ghi nhận giao dịch") },
        text = {
            Column(Modifier.heightIn(max = 540.dp).verticalScroll(rememberScrollState())) {
                Field("Ngày giờ", date, { date = it })
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("BUY", "SELL").forEach { v -> FilterChip(selected = side == v, onClick = { side = v }, label = { Text(v) }) }
                }
                Field("Entry", entry, { entry = it }, numeric = true)
                Field("Exit", exit, { exit = it }, numeric = true)
                Field("Stop Loss", sl, { sl = it }, numeric = true)
                Field("Take Profit", tp, { tp = it }, numeric = true)
                Field("Lot size", lot, { lot = it }, numeric = true)
                Field("Risk ($)", risk, { risk = it }, numeric = true)
                Field("P/L thực tế ($) — lãi dương, lỗ âm", pnl, { pnl = it }, numeric = true)
                Text("Kết quả: ${"%.2f".format(r)}R", color = if (r >= 0) Green else Red)
                Field("Phiên (Asia / London / New York)", session, { session = it })
                Field("Setup (OB / FVG / BOS / Sweep...)", setup, { setup = it })
                Field("Tâm lý", emotion, { emotion = it })
                Field("Ghi chú / lý do vào lệnh", notes, { notes = it })
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = ruleBreak, onCheckedChange = { ruleBreak = it })
                    Text("Có vi phạm kế hoạch?")
                }
                OutlinedButton(onClick = { imagePicker.launch("image/*") }, modifier = Modifier.fillMaxWidth()) {
                    Text(if (imagePath.isBlank()) "Đính kèm ảnh chart" else "Đã lưu ảnh chart vào thiết bị")
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val p = pnl.toDoubleOrNull() ?: 0.0
                onSave(Trade(
                    System.currentTimeMillis(), date, "XAU/USD", side, session, setup,
                    entry.toDoubleOrNull() ?: 0.0, exit.toDoubleOrNull() ?: 0.0,
                    sl.toDoubleOrNull() ?: 0.0, tp.toDoubleOrNull() ?: 0.0,
                    lot.toDoubleOrNull() ?: 0.01, riskD, p, r, notes, emotion, ruleBreak, imagePath
                ))
            }) { Text("Lưu giao dịch") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Hủy") } }
    )
}

@Composable
fun AnalyticsScreen(modifier: Modifier, trades: List<Trade>) {
    val wins = trades.filter { it.pnl > 0 }; val losses = trades.filter { it.pnl < 0 }
    val net = trades.sumOf { it.pnl }
    val grossWin = wins.sumOf { it.pnl }; val grossLoss = abs(losses.sumOf { it.pnl })
    val pf = if (grossLoss > 0) grossWin / grossLoss else if (grossWin > 0) Double.POSITIVE_INFINITY else 0.0
    val winRate = if (trades.isNotEmpty()) wins.size * 100.0 / trades.size else 0.0
    val avgR = if (trades.isNotEmpty()) trades.map { it.rMultiple }.average() else 0.0
    var cumulative = 0.0; var peak = 0.0; var maxDd = 0.0
    trades.sortedBy { it.date }.forEach { cumulative += it.pnl; peak = max(peak, cumulative); maxDd = max(maxDd, peak - cumulative) }
    Column(modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Text("PERFORMANCE ANALYTICS", fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Metric("Net P/L", "${if (net >= 0) "+" else ""}$${"%.2f".format(net)}", if (net >= 0) Green else Red, Modifier.weight(1f))
            Metric("Win Rate", "${"%.1f".format(winRate)}%", Color.White, Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Metric("Profit Factor", if (pf.isInfinite()) "∞" else "%.2f".format(pf), Color.White, Modifier.weight(1f))
            Metric("Average R", "%.2fR".format(avgR), Color.White, Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Metric("Total Trades", "${trades.size}", Color.White, Modifier.weight(1f))
            Metric("Max Equity DD", "$${"%.2f".format(maxDd)}", Red, Modifier.weight(1f))
        }
        AppCard {
            Text("Theo setup", fontWeight = FontWeight.Bold)
            trades.groupBy { it.setup }.forEach { (name, list) ->
                Text("$name · ${list.size} lệnh · P/L $${"%.2f".format(list.sumOf { it.pnl })}", color = Muted)
            }
            if (trades.isEmpty()) Text("Thêm giao dịch để xem thống kê.", color = Muted)
        }
        AppCard {
            Text("Theo phiên", fontWeight = FontWeight.Bold)
            trades.groupBy { it.session }.forEach { (name, list) ->
                Text("$name · ${list.size} lệnh · P/L $${"%.2f".format(list.sumOf { it.pnl })}", color = Muted)
            }
        }
    }
}

@Composable
fun Metric(label: String, value: String, color: Color, modifier: Modifier = Modifier) {
    Card(modifier.padding(bottom = 10.dp), colors = CardDefaults.cardColors(containerColor = Panel)) {
        Column(Modifier.padding(14.dp)) {
            Text(label, color = Muted, style = MaterialTheme.typography.labelSmall)
            Text(value, color = color, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun ReviewScreen(modifier: Modifier, trades: List<Trade>) {
    var good by remember { mutableStateOf("") }
    var mistake by remember { mutableStateOf("") }
    var next by remember { mutableStateOf("") }
    val net = trades.sumOf { it.pnl }
    val violations = trades.count { it.ruleBreak }
    Column(modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Text("WEEKLY REVIEW", fontWeight = FontWeight.Bold)
        AppCard {
            Text("TỔNG KẾT DỮ LIỆU ĐÃ GHI", fontWeight = FontWeight.Bold)
            Text("Số giao dịch: ${trades.size}")
            Text("Net P/L: $${"%.2f".format(net)}", color = if (net >= 0) Green else Red)
            Text("Vi phạm kế hoạch: $violations")
            Text("Lưu ý: tổng kết hiện dựa trên toàn bộ lịch sử đã lưu; chưa tự động lọc theo tuần.", color = Muted, style = MaterialTheme.typography.bodySmall)
        }
        AppCard {
            Text("1. Tuần này mình đã làm tốt điều gì?")
            Field("Ghi nhận", good, { good = it })
            Spacer(Modifier.height(12.dp))
            Text("2. Sai lầm lớn nhất là gì?")
            Field("Ghi nhận", mistake, { mistake = it })
            Spacer(Modifier.height(12.dp))
            Text("3. Tuần sau mình sẽ thay đổi điều gì?")
            Field("Ghi nhận", next, { next = it })
            Text("Các ghi chú review ở bản 1.0 chưa lưu thành lịch sử riêng.", color = Muted, style = MaterialTheme.typography.bodySmall)
        }
    }
}
